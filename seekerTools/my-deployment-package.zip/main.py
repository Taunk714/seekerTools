# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


import re
import requests  # 导入requests包
from bs4 import BeautifulSoup


# from bs4 import BeautifulSoup

def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.


def fetch_doulist(url):
    headers = {
        # 'Host': 'www.douban.com',
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36'
    }

    strhtml = requests.get(url, headers=headers)  # Get方式获取网页数据
    print(strhtml.text)


    #
    # html_doc = """
    # <html><head><title>The Dormouse's story</title></head>
    # <body>
    # <p class="title"><b>The Dormouse's story</b></p>
    # <p class="story">Once upon a time there were three little sisters; and their names were
    # <a href="http://example.com/elsie" class="sister" id="link1">Elsie</a>,
    # <a href="http://example.com/lacie" class="sister" id="link2">Lacie</a> and
    # <a href="http://example.com/tillie" class="sister" id="link3">Tillie</a>;
    # and they lived at the bottom of a well.</p>
    # <p class="story">...</p>
    # """
    # 创建一个BeautifulSoup解析对象
    soup = BeautifulSoup(strhtml.text, "html.parser", from_encoding="utf-8")
    doulist_name = soup.select('#content > div > div.article > div.doulist-item > div.mod > div.bd.doulist-subject')
    doulist = []
    for item in doulist_name:
        img = item.img.get('src')
        title = item.select('div > div.title')[0].text.strip()
        result = {
            'from': item.div.text.strip()[3:],
            'title': title,
            'cover': img,
            'cover_data': request_img(img, title),
            'link': item.a.get("href"),
            'author': item.select('div > div.abstract')[0].text.strip().split("\n")[0]
        }
        print(result)
        doulist.append(result)

    print(doulist)
    # print
    # "所有的链接"
    # for link in links:
    #     print
    #     link.name, link['href'], link.get_text()
    #
    # print
    # "获取特定的URL地址"
    # link_node = soup.find('a', href="http://example.com/elsie")
    # print
    # link_node.name, link_node['href'], link_node['class'], link_node.get_text()
    #
    # print
    # "正则表达式匹配"
    # link_node = soup.find('a', href=re.compile(r"ti"))
    # print
    # link_node.name, link_node['href'], link_node['class'], link_node.get_text()
    #
    # print
    # "获取P段落的文字"
    # p_node = soup.find('p', class_='story')
    # print
    # p_node.name, p_node['class'], p_node.get_text()

def request_img(img_url, title):
    strhtml = requests.get(img_url)  # Get方式获取网页数据
    with open(title.replace(' ', '_') +'.jpg', 'wb') as f:
        f.write(strhtml.content)
        f.close()
    return strhtml.content


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print_hi('PyCharm')
    url = "https://www.douban.com/doulist/150946850/"
    url2 = "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2620921357.jpg"
    fetch_doulist(url)

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
